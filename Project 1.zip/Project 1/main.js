//Gets the element by id
let newList = document.getElementById('to-doList');
let addList = document.getElementById('addBtn');
//Gets the element by using element name
let ulist = document.querySelector('ul');
//Holds the value from the input
let textValue = document.createTextNode(""); 

let checkboxOut = document.createElement('input');
checkboxOut.type = 'checkbox';
    
let mainList = document.querySelectorAll('li');
let listArray2 = Array.prototype.slice.call(mainList);

//Stores new value when input changes
newList.addEventListener('change', updateList);

//Function for the on-click button
function addNewList(e) {
    
    //Creates html element
    let head1 = document.createElement('h1');
    let list = document.createElement('li');
    let checkbox = document.createElement('input');
    let newBtn = document.createElement('button');
    let deleteNode = document.createTextNode('Delete');
    let num = mainList.length;
    
    //Makes the input as a checkbox
    checkbox.type = 'checkbox';
    //Makes an id for the checkbox and button
    checkbox.id = num;
    newBtn.id = 'dynamicBtn'
    
    //Takes the value of the textValue
    let h1Node = document.createTextNode(textValue.nodeValue);
    
    //Appends elements as its child elements
    list.appendChild(checkbox);
    list.appendChild(head1);
    list.appendChild(newBtn);
    newBtn.appendChild(deleteNode);
    ulist.appendChild(list);
    head1.appendChild(h1Node);
    
    let checkBoxValue = document.getElementById(num);
    checkboxOut = checkBoxValue;
        
    let theList = document.querySelectorAll('li');
    mainList = theList;
    
    //updateCheck function gets executed when checbox value is changed
    checkBoxValue.addEventListener('change', updateCheck);
}

//Function for newList.addEventListener
function updateList(e){
    //Passes the value from the input to the variable
    textValue.textContent = e.target.value;
}

//Putting line-through method
function updateCheck(e){ 
    
    if(e.target.checked){
        e.target.nextElementSibling.style.textDecoration = 'line-through'; 
     
    } 
    
    if(!e.target.checked){
        e.target.nextElementSibling.style.textDecoration = 'none';        
    }  

}

//When the button is clicked, this executes the addNewList function
addList.onclick = addNewList;